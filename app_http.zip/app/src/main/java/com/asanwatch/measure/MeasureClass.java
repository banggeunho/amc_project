package com.asanwatch.measure;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

public class MeasureClass extends Service implements SensorEventListener {
    private static final String TAG = "MeasureForegroundService";
    private SensorManager manager;
    private Sensor mAccel;
    private String time = "";
    private String x = "";
    private String y = "";
    private String z = "";
    private int count = 1;

    @Override
    public void onStart(Intent intent, int startId){
        foregroundNotification();
        initSensors();
    }

    @Override
    public void onDestroy(){
        unregister();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        Sensor sensor = event.sensor;
        long date = System.currentTimeMillis();
        if (sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            if(count%200==0) {
                time += Long.toString(date);
                x += event.values[0];
                y += event.values[1];
                z += event.values[2];
                RequestModule request = new RequestModule("time=" + time + "&x=" + x + "&y=" + y + "&z=" + z);
                request.execute();
                Log.d(TAG, x);
                count = 1;
                time = "";
                x = "";
                y = "";
                z = "";
            } else{
                time += Long.toString(date) + ",";
                x += event.values[0] + ",";
                y += event.values[1] + ",";
                z += event.values[2] + ",";
            }
            count += 1;
            if(SharedObjects.isWake){
                MainActivity.setMeasureText("Accelerometer \nX : " + event.values[0] + "\nY : " + event.values[1] + "\nZ : " + event.values[2]);
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    void foregroundNotification() { // foreground 실행 후 신호 전달 (안하면 앱 강제종료 됨)
        NotificationCompat.Builder builder;

        Intent notificationIntent = new Intent(this, MainActivity.class);
        notificationIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);

        if (Build.VERSION.SDK_INT >= 26) {
            String CHANNEL_ID = "measuring_service_channel";
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "Measuring Service Channel",
                    NotificationManager.IMPORTANCE_DEFAULT);

            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE))
                    .createNotificationChannel(channel);

            builder = new NotificationCompat.Builder(this, CHANNEL_ID);
        } else {
            builder = new NotificationCompat.Builder(this);
        }

        builder.setContentTitle("측정시작됨")
                .setContentIntent(pendingIntent);

        startForeground(1, builder.build());
    }

    private void initSensors(){
        manager = (SensorManager) this.getSystemService(SENSOR_SERVICE);
        mAccel = manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        manager.registerListener(this, mAccel, SensorManager.SENSOR_DELAY_GAME);
    }

    public void unregister() { // unregister listener
        manager.unregisterListener(this);
    }
}
