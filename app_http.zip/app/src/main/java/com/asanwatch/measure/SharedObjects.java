package com.asanwatch.measure;

public class SharedObjects {
    public static String address = "http://172.20.10.13:5000";
    public static String apiroute = "/api/watch/receiver";
    public static boolean isWake = true;
}
